<?php

function mytheme_post_thumbnails() {
    add_theme_support( 'post-thumbnails' );
}

add_action( 'after_setup_theme', 'mytheme_post_thumbnails' );

function hotcoffe_scripts() {
	wp_enqueue_script( 'hotcoffe-scroll', get_theme_file_uri( 'assets/js/scroll.js' ), array(), '20201214', true );
}

add_action( 'wp_enqueue_scripts', 'hotcoffe_scripts' );

// Register a new navigation menu
function add_Main_Nav() {
    register_nav_menu( 'header-menu', __( 'Header Menu' ) );
}
  // Hook to the init action hook, run our navigation menu function
add_action( 'init', 'add_Main_Nav' );