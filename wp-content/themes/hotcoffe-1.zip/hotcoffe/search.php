<?php get_header(); ?>

    <div class="post-homepage container">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div class="card-large">
                <div class="content-card">
                    <div class="header-card">
                        <h2><?php the_title(); ?></h2>
                    </div>
                    <div class="body-card">
                        <?php the_excerpt(); ?>
                    </div>
                    <div class="footer-card">
                        <div class="date">
                            <span><?php the_time('d M Y'); ?></span>
                        </div>
                        <div class="read-more">
                            <a href="<?php echo get_post_permalink(); ?>">Read more</a>
                        </div>
                    </div>
                </div>
                <?php
                    if ( has_post_thumbnail() ) {
                        $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
                        if ( ! empty( $large_image_url[0] ) ) {
                            echo '<div class="thumbnail-card" style="background-image: url(' . esc_url( $large_image_url[0] ) . ');">';
                                // echo '<img height="100%" src="' . esc_url( $large_image_url[0] ) . '" title="' . the_title_attribute( array( 'echo' => 0 ) ) . '"';
                            echo '</div>';
                        }
                    }
                ?>
                <!-- <div class="thumbnail-card">
                    <img height="100%" src="<?php get_the_post_thumbnail_url(); ?>" alt="">
                </div> -->
            </div>
        <?php endwhile; endif; ?>
    </div>
    <div class="container">
        <div class="next-or-prev">
            <a class="buttons-next-prev" href="#"><- Previus Page</a>
            <a class="buttons-next-prev" href="#">Next Page -></a>
        </div>
    </div>

<?php get_footer(); ?>