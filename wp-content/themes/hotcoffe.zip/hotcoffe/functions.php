<?php

function mytheme_post_thumbnails() {
    add_theme_support( 'post-thumbnails' );
}

add_action( 'after_setup_theme', 'mytheme_post_thumbnails' );

function hotcoffe_scripts() {
  wp_enqueue_style( 'hotcoffe-style', get_template_directory_uri() . '/assets/css/normalize.css');
  wp_enqueue_style( 'hotcoffe-comments', get_template_directory_uri() . '/assets/css/comments.css');
  wp_enqueue_script( 'hotcoffe-scroll', get_theme_file_uri( 'assets/js/scroll.js' ), array(), '20201214', true );
}

add_action( 'wp_enqueue_scripts', 'hotcoffe_scripts' );

// Register a new navigation menu
function add_Main_Nav() {
    register_nav_menu( 'header-menu', __( 'Header Menu' ) );
}
  // Hook to the init action hook, run our navigation menu function
add_action( 'init', 'add_Main_Nav' );


// function hotcoffe_widgets_init() {
//   register_sidebar( array(
//     'name'          => __( 'Footer Widgets', 'hotcoffe' ),
//     'id'            => 'sidebar-2',
//     'description'   => __( 'Add widgets here to appear in your footer area.', 'hotcoffe' ),
//     'before_widget' => '<aside id="%1$s" class="widget %2$s">',
//     'after_widget'  => '</aside>',
//     'before_title'  => '<h2 class="widget-title">',
//     'after_title'   => '</h2>',
//   ) );
// }
// add_action( 'widgets_init', 'hotcoffe_widgets_init' );